# SDS Component Metadata (JS Console)

[Instructions](/README.md#scriptscomponent-metadata)
