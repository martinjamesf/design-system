# SDS Dev Resources (REST)

[Instructions](/README.md#scriptsdev-resources)
