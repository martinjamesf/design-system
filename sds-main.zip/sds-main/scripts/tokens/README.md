# SDS Token Generator (REST or Plugin)

[Instructions](/README.md#scriptstokens)
