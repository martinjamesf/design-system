# SDS Icon Generator (REST or Plugin)

[Instructions](/README.md#scriptsicons)
