import { figma } from "@figma/code-connect";
import { Footer } from "compositions";

figma.connect(Footer, "<FIGMA_SECTIONS_FOOTER>");
