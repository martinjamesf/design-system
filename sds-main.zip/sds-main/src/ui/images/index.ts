import placeholderSvg from "./placeholder.svg";
export const placeholder = placeholderSvg;
